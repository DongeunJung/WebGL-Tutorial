# WebGL Tutorial Project

#https://www.khronos.org/opengl/wiki/Main_Page

#https://stackoverflow.com/questions/32879043/in-webgl-how-does-an-array-element-buffer-know-which-array-buffer-to-reference

#https://www.shaderific.com/glsl-qualifiers

#https://www.opengl.org/sdk/docs/tutorials/ClockworkCoders/varying.php

#https://stackoverflow.com/questions/33863426/vaos-and-element-buffer-objects

#https://developer.mozilla.org/en-US/

#https://www.youtube.com/watch?v=kB0ZVUrI4Aw&list=WL&index=20&t=2337s

#https://www.youtube.com/watch?v=3yLL9ADo-ko&list=WL&index=18